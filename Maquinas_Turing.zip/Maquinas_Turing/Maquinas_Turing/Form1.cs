﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Maquinas_Turing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dgv_display.Columns.Add("", "");
        }

        int operacion = 0;
        bool graficar = true;
        List<char> input = new List<char>();
        int i = 0;
        string estado = "q0";
        int paso = 0;
        string error = " ";
        bool bandera = true;
        bool validada = false;
        bool MT = true;
        bool incorrecto = false;
        string palabra = "";
        bool mensaje = false;
        bool primer = true;
        bool termino = false;

        private void Palindromo()
        {
            switch (input[i])
            {
                #region B
                case 'B':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q8";
                        validada = true;
                        mensaje = true;
                        bandera = false;
                        termino = true;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                        tmr_timer.Stop();
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q4";
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q5";
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q6";
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q4")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q8";
                        validada = true;
                        mensaje = true;
                        bandera = false;
                        termino = true;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                        tmr_timer.Stop();
                    }
                    else if (estado == "q5")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q8";
                        validada = true;
                        mensaje = true;
                        bandera = false;
                        termino = true;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                        tmr_timer.Stop();
                    }
                    else if (estado == "q6")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q8";
                        validada = true;
                        mensaje = true;
                        bandera = false;
                        termino = true;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                        tmr_timer.Stop();
                    }
                    else
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q0";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region a
                case 'a':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        input[i] = 'B';
                        dgv_display.Rows[0].Cells[i].Value = ' ';
                        estado = "q1";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q4")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        input[i] = 'B';
                        dgv_display.Rows[0].Cells[i].Value = ' ';
                        estado = "q7";
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q7")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else
                    {
                        bandera = false;
                        MT = false;
                        mensaje = true;
                        tmr_timer.Stop();
                    }

                    break;
                #endregion
                #region b
                case 'b':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        input[i] = 'B';
                        dgv_display.Rows[0].Cells[i].Value = ' ';
                        estado = "q2";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q5")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        input[i] = 'B';
                        dgv_display.Rows[0].Cells[i].Value = ' ';
                        estado = "q7";
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q7")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else
                    {
                        mensaje = true;
                        bandera = false;
                        MT = false;
                        tmr_timer.Stop();
                    }

                    break;
                #endregion
                #region c
                case 'c':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        input[i] = 'B';
                        dgv_display.Rows[0].Cells[i].Value = ' ';
                        estado = "q3";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q6")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        input[i] = 'B';
                        dgv_display.Rows[0].Cells[i].Value = ' ';
                        estado = "q7";
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q7")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else
                    {
                        bandera = false;
                        MT = false;
                        mensaje = true;
                        tmr_timer.Stop();
                    }

                    break;
                #endregion
                default:
                    bandera = false;
                    incorrecto = true;
                    mensaje = true;
                    error = input[i].ToString();
                    tmr_timer.Stop();
                    break;
            }

            if(mensaje)
            {
                if (bandera == false && incorrecto == true)
                {
                    MessageBox.Show("El símbolo " + error + " no está dentro del lenguaje permitido");
                }

                if (bandera == false && MT == false)
                {
                    MessageBox.Show("La cadena no es un palíndromo");
                }

                if (bandera == false && validada == true)
                {
                    MessageBox.Show("La cadena sí es un palíndromo");
                }
            }
        }

        private void Patron()
        {
            switch (input[i])
            {
                #region a
                case 'a':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        input[i] = 'M';
                        dgv_display.Rows[0].Cells[i].Value = 'M';
                        estado = "q1";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q4")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q5")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else 
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region b
                case 'b':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        input[i] = 'M';
                        dgv_display.Rows[0].Cells[i].Value = 'M';
                        estado = "q2";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q4")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q5")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    break;
                #endregion
                #region c
                case 'c':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        input[i] = 'M';
                        dgv_display.Rows[0].Cells[i].Value = 'M';
                        estado = "q3";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q4")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q5")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else 
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region B
                case 'B':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q7";
                        i++;
                        validada = true;
                        mensaje = true;
                        bandera = false;
                        termino = true;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                        tmr_timer.Stop();
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q4";
                        input[i] = 'X';
                        dgv_display.Rows[0].Cells[i].Value = 'X';
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q5";
                        input[i] = 'Y';
                        dgv_display.Rows[0].Cells[i].Value = 'Y';
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q6";
                        input[i] = 'Z';
                        dgv_display.Rows[0].Cells[i].Value = 'Z';
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region X
                case 'X':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        input[i] = 'a';
                        dgv_display.Rows[0].Cells[i].Value = 'a';
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q4")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q5")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region Y
                case 'Y':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        input[i] = 'b';
                        dgv_display.Rows[0].Cells[i].Value = 'b';
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q4")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q5")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else 
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region Z
                case 'Z':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        input[i] = 'c';
                        dgv_display.Rows[0].Cells[i].Value = 'c';
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q4")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q5")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else 
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region M
                case 'M':
                    if (estado == "q4")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q0";
                        input[i] = 'a';
                        dgv_display.Rows[0].Cells[i].Value = 'a';
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q5")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q0";
                        input[i] = 'b';
                        dgv_display.Rows[0].Cells[i].Value = 'b';
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else 
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q0";
                        input[i] = 'c';
                        dgv_display.Rows[0].Cells[i].Value = 'c';
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                default:
                    bandera = false;
                    incorrecto = true;
                    mensaje = true;
                    error = input[i].ToString();
                    tmr_timer.Stop();
                    break;
            }
            
            if (mensaje)
            {
                if (bandera == false && incorrecto == true)
                {
                    MessageBox.Show("El símbolo " + error + " no está dentro del lenguaje permitido");
                }

                if (bandera == false && validada == true)
                {
                    MessageBox.Show("El patrón ha sido duplicado");
                }
            }
        }

        private void Multiplicacion()
        {
            switch (input[i])
            {
                #region 1
                case '1':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q1";
                        input[i] = 'X';
                        dgv_display.Rows[0].Cells[i].Value = 'X';
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q1";
                        input[i] = 'Y';
                        dgv_display.Rows[0].Cells[i].Value = 'Y';
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q4")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else 
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region *
                case '*':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q6";
                        validada = true;
                        mensaje = true;
                        bandera = false;
                        termino = true;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                        tmr_timer.Stop();
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q2";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else 
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region =
                case '=':
                    if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q3";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q5";
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else 
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                   
                    break;
                #endregion
                #region B
                case 'B':
                    if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q4";
                        input[i] = '1';
                        dgv_display.Rows[0].Cells[i].Value = '1';
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region X
                case 'X':
                    if (estado == "q5")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q0";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    
                    break;
                #endregion
                #region Y
                case 'Y':
                    if (estado == "q4")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q2";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else 
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        input[i] = '1';
                        dgv_display.Rows[0].Cells[i].Value = '1';
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                    #endregion
                default:
                    bandera = false;
                    incorrecto = true;
                    error = input[i].ToString();
                    break;
            }

            if (mensaje)
            {
                if (bandera == false && incorrecto == true)
                {
                    MessageBox.Show("El símbolo " + error + " no está dentro del lenguaje permitido");
                }

                if (bandera == false && validada == true)
                {
                    MessageBox.Show("Se ha realizado la multiplicación");
                }
            }
        }

        private void Suma()
        {
            switch (input[i])
            {
                #region 1
                case '1':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q1";
                        input[i] = 'X';
                        dgv_display.Rows[0].Cells[i].Value = 'X';
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region +
                case '+':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region =
                case '=':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q3";
                        validada = true;
                        mensaje = true;
                        bandera = false;
                        termino = true;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                        tmr_timer.Stop();
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else 
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region B
                case 'B':
                    if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q2";
                        input[i] = '1';
                        dgv_display.Rows[0].Cells[i].Value = '1';
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region X
                case 'X':
                    if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q0";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                default:
                    bandera = false;
                    incorrecto = true;
                    error = input[i].ToString();
                    break;
            }

            if(mensaje)
            {
                if (bandera == false && incorrecto == true)
                {
                    MessageBox.Show("El símbolo " + error + " no está dentro del lenguaje permitido");
                }

                if (bandera == false && validada == true)
                {
                    MessageBox.Show("La suma se ha realizado");
                }
            }
        }

        private void Resta()
        {
            switch (input[i])
            {
                #region 1
                case '1':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q1";
                        input[i] = 'X';
                        dgv_display.Rows[0].Cells[i].Value = 'X';
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q3";
                        input[i] = 'Y';
                        dgv_display.Rows[0].Cells[i].Value = 'Y';
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q4")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else 
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    
                    break;
                #endregion
                #region -
                case '-':
                    if (estado == "q0")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q6";
                        validada = true;
                        mensaje = true;
                        bandera = false;
                        termino = true;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                        tmr_timer.Stop();
                    }
                    else if (estado == "q1")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q2";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q3";
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else 
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region =
                case '=':
                    if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q4";
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region B
                case 'B':
                    if (estado == "q4")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q5";
                        input[i] = '1';
                        dgv_display.Rows[0].Cells[i].Value = '1';
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    
                    break;
                #endregion
                #region X
                case 'X':
                    if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q0";
                        input[i] = 'X';
                        dgv_display.Rows[0].Cells[i].Value = 'X';
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q0";
                        input[i] = 'X';
                        dgv_display.Rows[0].Cells[i].Value = 'X';
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                #region Y
                case 'Y':
                    if (estado == "q2")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i++;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else if (estado == "q3")
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }
                    else
                    {
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
                        estado = "q5";
                        i--;
                        dgv_display.Rows[1].Cells[i].Style.BackColor = Color.SlateBlue;
                    }

                    break;
                #endregion
                default:
                    bandera = false;
                    incorrecto = true;
                    error = input[i].ToString();
                    break;
            }

            if(mensaje)
            {
                if (bandera == false && incorrecto == true)
                {
                    MessageBox.Show("El símbolo " + error + " no está dentro del lenguaje permitido");
                }

                if (bandera == false && validada == true)
                {
                    MessageBox.Show("La resta se ha realizado");
                }
            }
        }

        private void tmr_timer_Tick(object sender, EventArgs e)
        {
            switch (operacion)
            {
                case 1: 
                    Palindromo();
                    break;
                case 2: 
                    Patron();
                    break;
                case 3: 
                    Multiplicacion();
                    break;
                case 4: 
                    Suma();
                    break;
                case 5: 
                    Resta();
                    break;
            }

            paso++;
            txt_estado.Text = estado;
            txt_paso.Text = paso.ToString();
        }

        private void ListaGrafica()
        {
            for (int i = 0; i < palabra.Length; i++)
            {
                input.Add(palabra[i]);
            }

            if (operacion == 1)
            {
                input.Add('B');
            }
            else if (operacion == 2)
            {
                for (int i = 0; i <= (palabra.Length + 1); i++)
                {
                    input.Add('B');
                }
            }
            else if (operacion == 3)
            {
                string[] p1 = palabra.Split('*');
                string[] p2 = p1[1].Split('=');
                int mult1 = 0;
                int mult2 = 0;

                if (p2.Length == 1)
                {
                    input.Add('=');
                }

                for (int i = 0; i < p1[0].Length; i++)
                {
                    mult1++;
                }

                for (int i = 0; i < p2[0].Length; i++)
                {
                    mult2++;
                }

                int m = mult1 * mult2;

                for (int i = 0; i < m; i++)
                {
                    input.Add('B');
                }
            }
            else if (operacion == 4)
            {
                string[] p1 = palabra.Split('=');

                if (p1.Length == 1)
                {
                    input.Add('=');
                }

                for (int i = 0; i < (p1[0].Length - 1); i++)
                {
                    input.Add('B');
                }
            }
            else
            {
                string[] p1 = palabra.Split('-');
                string[] p2 = p1[1].Split('=');
                int rest1 = 0;
                int rest2 = 0;

                if (p2.Length == 1)
                {
                    input.Add('=');
                }

                for (int i = 0; i < p1[0].Length; i++)
                {
                    rest1++;
                }

                for (int i = 0; i < p2[0].Length; i++)
                {
                    rest2++;
                }

                int r = rest1 - rest2;

                for (int i = 0; i < r; i++)
                {
                    input.Add('B');
                }
            }

            for (int i = 0; i < (input.Count - 1); i++)
            {
                dgv_display.Columns.Add("", "");
            }

            dgv_display.Rows.Add();

            for (int j = 0; j < input.Count; j++)
            {
                if (input[j] == 'B')
                {
                    dgv_display.Rows[0].Cells[j].Value = ' ';
                }
                else
                {
                    dgv_display.Rows[0].Cells[j].Value = input[j];
                }
            }

            dgv_display.Rows[1].Cells[0].Style.BackColor = Color.SlateBlue;
            graficar = false;
        }

        private void btn_run_Click(object sender, EventArgs e)
        {
            palabra = txt_input.Text;

            if (palabra.Length > 0)
            {
                if (operacion != 0)
                {
                    if(graficar)
                    {
                        ListaGrafica();
                    }
                    tmr_timer.Start();
                }
                else
                {
                    MessageBox.Show("Escoja la máquina de Turing que quiere utilizar");
                }
            }
            else
            {
                MessageBox.Show("Ingrese una cadena para trabajar");
            }
        }

        private void btn_step_Click(object sender, EventArgs e)
        {
            if(!termino)
            {
                if (primer && graficar)
                {
                    palabra = txt_input.Text;

                    if (palabra.Length > 0)
                    {
                        if (operacion != 0)
                        {
                            if (graficar)
                            {
                                ListaGrafica();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Escoja la máquina de Turing que quiere utilizar");
                        }
                        primer = false;
                    }
                    else
                    {
                        MessageBox.Show("Ingrese una cadena para trabajar");
                    }
                }
                else
                {
                    switch (operacion)
                    {
                        case 1:
                            Palindromo();
                            break;
                        case 2:
                            Patron();
                            break;
                        case 3:
                            Multiplicacion();
                            break;
                        case 4:
                            Suma();
                            break;
                        case 5:
                            Resta();
                            break;
                    }

                    paso++;
                    txt_estado.Text = estado;
                    txt_paso.Text = paso.ToString();
                }
            }
        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            dgv_display.Rows[1].Cells[i].Style.BackColor = Color.White;
            i = 0;
            estado = "q0";
            paso = 0;
            error = " ";
            bandera = true;
            validada = false;
            MT = true;
            incorrecto = false;
            mensaje = false;
            primer = true;
            termino = false;
            palabra = txt_input.Text;
            input.Clear();
            Reset();
            graficar = true;
            ListaGrafica();
            txt_estado.Text = estado;
            txt_paso.Text = paso.ToString();
        }

        private void Reset()
        {
            int rows = dgv_display.Rows.Count;
            int col = dgv_display.ColumnCount;

            dgv_display.Rows.RemoveAt(0);

            for (int i = 0; i < (col -1); i++)
            {
                dgv_display.Columns.RemoveAt(0);
            }
        }

        private void palíndromoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            operacion = 1;
        }

        private void patronesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            operacion = 2;
        }

        private void multiplicaciónUnariaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            operacion = 3;
        }

        private void sumaUnariaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            operacion = 4;
        }

        private void restaUnariaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            operacion = 5;
        }
    }
}

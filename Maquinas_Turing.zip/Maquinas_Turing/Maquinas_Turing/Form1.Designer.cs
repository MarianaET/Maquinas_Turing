﻿namespace Maquinas_Turing
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txt_input = new System.Windows.Forms.TextBox();
            this.btn_run = new System.Windows.Forms.Button();
            this.lb_input = new System.Windows.Forms.Label();
            this.dgv_display = new System.Windows.Forms.DataGridView();
            this.txt_estado = new System.Windows.Forms.TextBox();
            this.txt_paso = new System.Windows.Forms.TextBox();
            this.lb_estado = new System.Windows.Forms.Label();
            this.lb_paso = new System.Windows.Forms.Label();
            this.mns_maquinas = new System.Windows.Forms.MenuStrip();
            this.máquinasDeTuringToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.palíndromoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.patronesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.multiplicaciónUnariaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sumaUnariaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restaUnariaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btn_reset = new System.Windows.Forms.Button();
            this.btn_step = new System.Windows.Forms.Button();
            this.tmr_timer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_display)).BeginInit();
            this.mns_maquinas.SuspendLayout();
            this.SuspendLayout();
            // 
            // txt_input
            // 
            this.txt_input.Location = new System.Drawing.Point(352, 44);
            this.txt_input.Name = "txt_input";
            this.txt_input.Size = new System.Drawing.Size(261, 20);
            this.txt_input.TabIndex = 0;
            // 
            // btn_run
            // 
            this.btn_run.Location = new System.Drawing.Point(905, 27);
            this.btn_run.Name = "btn_run";
            this.btn_run.Size = new System.Drawing.Size(75, 23);
            this.btn_run.TabIndex = 1;
            this.btn_run.Text = "Run";
            this.btn_run.UseVisualStyleBackColor = true;
            this.btn_run.Click += new System.EventHandler(this.btn_run_Click);
            // 
            // lb_input
            // 
            this.lb_input.AutoSize = true;
            this.lb_input.Location = new System.Drawing.Point(304, 47);
            this.lb_input.Name = "lb_input";
            this.lb_input.Size = new System.Drawing.Size(31, 13);
            this.lb_input.TabIndex = 2;
            this.lb_input.Text = "Input";
            // 
            // dgv_display
            // 
            this.dgv_display.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_display.Location = new System.Drawing.Point(14, 135);
            this.dgv_display.Name = "dgv_display";
            this.dgv_display.Size = new System.Drawing.Size(966, 84);
            this.dgv_display.TabIndex = 3;
            // 
            // txt_estado
            // 
            this.txt_estado.Location = new System.Drawing.Point(340, 100);
            this.txt_estado.Name = "txt_estado";
            this.txt_estado.ReadOnly = true;
            this.txt_estado.Size = new System.Drawing.Size(105, 20);
            this.txt_estado.TabIndex = 4;
            // 
            // txt_paso
            // 
            this.txt_paso.Location = new System.Drawing.Point(518, 100);
            this.txt_paso.Name = "txt_paso";
            this.txt_paso.ReadOnly = true;
            this.txt_paso.Size = new System.Drawing.Size(105, 20);
            this.txt_paso.TabIndex = 5;
            // 
            // lb_estado
            // 
            this.lb_estado.AutoSize = true;
            this.lb_estado.Location = new System.Drawing.Point(297, 102);
            this.lb_estado.Name = "lb_estado";
            this.lb_estado.Size = new System.Drawing.Size(39, 13);
            this.lb_estado.TabIndex = 6;
            this.lb_estado.Text = "estado";
            // 
            // lb_paso
            // 
            this.lb_paso.AutoSize = true;
            this.lb_paso.Location = new System.Drawing.Point(471, 103);
            this.lb_paso.Name = "lb_paso";
            this.lb_paso.Size = new System.Drawing.Size(30, 13);
            this.lb_paso.TabIndex = 7;
            this.lb_paso.Text = "paso";
            // 
            // mns_maquinas
            // 
            this.mns_maquinas.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.máquinasDeTuringToolStripMenuItem});
            this.mns_maquinas.Location = new System.Drawing.Point(0, 0);
            this.mns_maquinas.Name = "mns_maquinas";
            this.mns_maquinas.Size = new System.Drawing.Size(992, 24);
            this.mns_maquinas.TabIndex = 8;
            this.mns_maquinas.Text = "menuStrip1";
            // 
            // máquinasDeTuringToolStripMenuItem
            // 
            this.máquinasDeTuringToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.palíndromoToolStripMenuItem,
            this.patronesToolStripMenuItem,
            this.multiplicaciónUnariaToolStripMenuItem,
            this.sumaUnariaToolStripMenuItem,
            this.restaUnariaToolStripMenuItem});
            this.máquinasDeTuringToolStripMenuItem.Name = "máquinasDeTuringToolStripMenuItem";
            this.máquinasDeTuringToolStripMenuItem.Size = new System.Drawing.Size(125, 20);
            this.máquinasDeTuringToolStripMenuItem.Text = "Máquinas de Turing";
            // 
            // palíndromoToolStripMenuItem
            // 
            this.palíndromoToolStripMenuItem.Name = "palíndromoToolStripMenuItem";
            this.palíndromoToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.palíndromoToolStripMenuItem.Text = "Palíndromo";
            this.palíndromoToolStripMenuItem.Click += new System.EventHandler(this.palíndromoToolStripMenuItem_Click);
            // 
            // patronesToolStripMenuItem
            // 
            this.patronesToolStripMenuItem.Name = "patronesToolStripMenuItem";
            this.patronesToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.patronesToolStripMenuItem.Text = "Patrones";
            this.patronesToolStripMenuItem.Click += new System.EventHandler(this.patronesToolStripMenuItem_Click);
            // 
            // multiplicaciónUnariaToolStripMenuItem
            // 
            this.multiplicaciónUnariaToolStripMenuItem.Name = "multiplicaciónUnariaToolStripMenuItem";
            this.multiplicaciónUnariaToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.multiplicaciónUnariaToolStripMenuItem.Text = "Multiplicación Unaria";
            this.multiplicaciónUnariaToolStripMenuItem.Click += new System.EventHandler(this.multiplicaciónUnariaToolStripMenuItem_Click);
            // 
            // sumaUnariaToolStripMenuItem
            // 
            this.sumaUnariaToolStripMenuItem.Name = "sumaUnariaToolStripMenuItem";
            this.sumaUnariaToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.sumaUnariaToolStripMenuItem.Text = "Suma Unaria";
            this.sumaUnariaToolStripMenuItem.Click += new System.EventHandler(this.sumaUnariaToolStripMenuItem_Click);
            // 
            // restaUnariaToolStripMenuItem
            // 
            this.restaUnariaToolStripMenuItem.Name = "restaUnariaToolStripMenuItem";
            this.restaUnariaToolStripMenuItem.Size = new System.Drawing.Size(187, 22);
            this.restaUnariaToolStripMenuItem.Text = "Resta Unaria";
            this.restaUnariaToolStripMenuItem.Click += new System.EventHandler(this.restaUnariaToolStripMenuItem_Click);
            // 
            // btn_reset
            // 
            this.btn_reset.Location = new System.Drawing.Point(905, 100);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(75, 23);
            this.btn_reset.TabIndex = 9;
            this.btn_reset.Text = "De nuevo";
            this.btn_reset.UseVisualStyleBackColor = true;
            this.btn_reset.Click += new System.EventHandler(this.btn_reset_Click);
            // 
            // btn_step
            // 
            this.btn_step.Location = new System.Drawing.Point(905, 63);
            this.btn_step.Name = "btn_step";
            this.btn_step.Size = new System.Drawing.Size(75, 23);
            this.btn_step.TabIndex = 10;
            this.btn_step.Text = "Por paso";
            this.btn_step.UseVisualStyleBackColor = true;
            this.btn_step.Click += new System.EventHandler(this.btn_step_Click);
            // 
            // tmr_timer
            // 
            this.tmr_timer.Interval = 500;
            this.tmr_timer.Tick += new System.EventHandler(this.tmr_timer_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(992, 223);
            this.Controls.Add(this.btn_step);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.lb_paso);
            this.Controls.Add(this.lb_estado);
            this.Controls.Add(this.txt_paso);
            this.Controls.Add(this.txt_estado);
            this.Controls.Add(this.dgv_display);
            this.Controls.Add(this.lb_input);
            this.Controls.Add(this.btn_run);
            this.Controls.Add(this.txt_input);
            this.Controls.Add(this.mns_maquinas);
            this.MainMenuStrip = this.mns_maquinas;
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_display)).EndInit();
            this.mns_maquinas.ResumeLayout(false);
            this.mns_maquinas.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_input;
        private System.Windows.Forms.Button btn_run;
        private System.Windows.Forms.Label lb_input;
        private System.Windows.Forms.DataGridView dgv_display;
        private System.Windows.Forms.TextBox txt_estado;
        private System.Windows.Forms.TextBox txt_paso;
        private System.Windows.Forms.Label lb_estado;
        private System.Windows.Forms.Label lb_paso;
        private System.Windows.Forms.MenuStrip mns_maquinas;
        private System.Windows.Forms.ToolStripMenuItem máquinasDeTuringToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem palíndromoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem patronesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem multiplicaciónUnariaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sumaUnariaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem restaUnariaToolStripMenuItem;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Button btn_step;
        private System.Windows.Forms.Timer tmr_timer;
    }
}

